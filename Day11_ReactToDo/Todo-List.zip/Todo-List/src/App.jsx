import React from 'react'
import { useState } from 'react'
import "./App.css"
import  TodoInput from "./components/TodoInput"
import  ToDoList from "./components/ToDoList"


function App() {
  const [listTodo,setListTodo] = useState([]);
  let addList = (inputText)=>{
  if(inputText!==''){
      setListTodo([...listTodo,inputText]);
    }
  }
 
  const deleteItem = (key) =>{
    let updList =[...listTodo];
    updList.splice(key,1)
    setListTodo([...updList])
  }
  return (
  <div className="main-container">
    <div className="center-container">
      <img className='imgLogo' src="./src/todo.jpg" width={"150px"} height={"130px"}></img>
      <h1 className="app-head">
          <center> To Do List </center>
      </h1>
  <hr></hr>
  <br></br>
        <TodoInput addList={addList}></TodoInput>
        {listTodo.map((listItem,i)=>{
        return(
            <ToDoList key={i} index={i} item={listItem} deleteItem={deleteItem}></ToDoList>
        )
      })}
    </div>
</div>  
)
}

export default App