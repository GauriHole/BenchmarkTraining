import MyForm from "./components/MyForm";
import './App.css'

const App = ()=> {
  return (
    <>
      <MyForm></MyForm>
    </>
  )
}

export default App
