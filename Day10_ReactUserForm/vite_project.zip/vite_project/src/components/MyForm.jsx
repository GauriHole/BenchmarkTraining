import { useState } from "react";
import './MyForm.css'

const MyForm = () => {
  const [data, setData] = useState({ fname: "",lname: "", age: 0 ,gender:"",skills:"",mobile:"+91"});
    return (
        <form>
          <h1>
            User - {data.fname} | {data.lname} | {data.age} | {data.gender} | {data.skills} | {data.mobile}
          </h1>
          <input
            value={data.fname}
            placeholder="First Name: "
            onChange={(e) => setData({ ...data, fname: e.target.value })}
          /> <br></br>
          <input
            value={data.lname}
            placeholder="Last Name: "
            onChange={(e) => setData({ ...data, lname: e.target.value })}
          /> <br></br>
          <input
            value={Number(data.age)}
            placeholder="Age: "
            onChange={(e) => setData({ ...data, age: Number(e.target.value) })}
          /> <br></br>
          <input type="radio" className="radio"
            checked={data.gender === "Female"}
            name="gender"
            value="Female"
            onChange={(e) => setData({ ...data, gender: e.target.value })}
          /> Female 
          <input className="radio" type="radio"
            checked={data.gender === "Male"}
            name="gender"
            value="Male"
            onChange={(e) => setData({ ...data, gender: e.target.value })}
          /> Male <br></br>
        <select value={data.skills} onChange={(e) => setData({ ...data, skills: e.target.value})}>
          <option name="default">Select Skill</option>
          <option name="dancing">Dancing</option>
          <option name="singing">Singing</option>
          <option name="reading books">Reading Books</option>
          <option name="coding">Coding</option>
        </select> <br></br>
        <input
            value={Number(data.mobile)}
            placeholder="Mobile no: "
            onChange={(e) => setData({ ...data, mobile: Number(e.target.value) })}
          /><br></br> <br></br>
        <button type="submit" onClick={(e) => { 
          e.preventDefault(); // Prevent page reload
          alert("Data Added Successfully..."); 
        }}> 
            Submit form
        </button>
      </form>
      );
}
  export default MyForm;